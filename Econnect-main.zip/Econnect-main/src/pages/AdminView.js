// =================================================================
// FICHIER : src/pages/AdminView.js
// Rôle : Le tableau de bord de l'administrateur avec l'horloge dans l'en-tête.
// =================================================================

import React, { useState, useEffect } from 'react';
import { icons } from '../api/mockData';
import Icon from '../components/Icon';
import Dashboard from './Dashboard';
import Fleet from './Fleet';
import Shelters from './Shelters';
import Placeholder from './Placeholder';
import UserTracking from './UserTracking';
import BsbLogsView from './BsbLogsView';

const AdminView = () => {
  const [activeView, setActiveView] = useState('dashboard');
  const [isLoaded, setIsLoaded] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const clockTimer = setInterval(() => setCurrentTime(new Date()), 1000);
    const loadTimer = setTimeout(() => setIsLoaded(true), 200);
    return () => {
      clearInterval(clockTimer);
      clearTimeout(loadTimer);
    };
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Tableau de Bord', icon: icons.dashboard },
    { id: 'bsb', label: 'BSB Live Logs', icon: icons.bsb },
    { id: 'users', label: 'Suivi Utilisateurs', icon: icons.users },
    { id: 'fleet', label: 'Flotte', icon: icons.fleet },
    { id: 'alerts', label: 'Alertes', icon: icons.alerts },
    { id: 'routes', label: 'Optimisation', icon: icons.routes },
    { id: 'maintenance', label: 'Maintenance', icon: icons.maintenance },
    { id: 'analytics', label: 'Analyses', icon: icons.analytics },
    { id: 'shelters', label: 'Abribus', icon: icons.shelters },
  ];

  const renderAdminView = () => {
    switch (activeView) {
      case 'dashboard': return <Dashboard />;
      case 'bsb': return <BsbLogsView />;
      case 'users': return <UserTracking />;
      case 'fleet': return <Fleet />;
      case 'shelters': return <Shelters />;
      default: return <Placeholder title={menuItems.find(item => item.id === activeView)?.label || ''} />;
    }
  };

  const getCurrentViewTitle = () => {
    return menuItems.find(item => item.id === activeView)?.label || 'Dashboard';
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-gray-900 via-purple-900 to-gray-800 text-white font-sans relative overflow-hidden">
      {/* Sidebar */}
      <nav className={`${sidebarCollapsed ? 'w-20' : 'w-64'} bg-gray-900/70 backdrop-blur-xl border-r border-purple-500/20 flex flex-col transition-all duration-300 z-20`}>
        <div className="p-4 border-b border-purple-500/20 flex items-center justify-center">
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="p-2 rounded-lg bg-purple-600/20 hover:bg-purple-600/40 text-purple-300 transition-all duration-300"
            >
              <svg className={`w-5 h-5 transform transition-transform duration-300 ${sidebarCollapsed ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
        </div>
        <div className="flex-grow py-4">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.id} className="px-4">
                <button
                  onClick={() => setActiveView(item.id)}
                  title={item.label}
                  className={`group flex items-center w-full text-left py-3 px-4 rounded-xl transition-all duration-300 relative ${
                    activeView === item.id 
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25' 
                    : 'text-gray-300 hover:bg-gray-800/50 hover:text-white'
                  }`}
                >
                  <Icon path={item.icon} />
                  {!sidebarCollapsed && (
                      <span className="ml-4 font-medium">{item.label}</span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Contenu principal */}
      <main className="flex-1 flex flex-col z-10">
        <header className="bg-gray-900/50 backdrop-blur-xl border-b border-purple-500/20 p-6">
          <div className="flex items-center justify-between">
            <div className={`transform transition-all duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0 -translate-x-5'}`}>
              <h1 className="text-2xl font-bold text-white">{getCurrentViewTitle()}</h1>
            </div>
            <div className={`bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-4 shadow-lg transform transition-all duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0 translate-x-5'}`}>
                <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                    <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">Heure locale</p>
                        <p className="text-2xl font-bold text-white font-mono">
                            {currentTime.toLocaleTimeString('fr-FR')}
                        </p>
                    </div>
                </div>
            </div>
          </div>
        </header>

        <div className="flex-1 p-6 lg:p-8 overflow-y-auto">
          <div className={`transform transition-all duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`} style={{transitionDelay: '200ms'}}>
            {renderAdminView()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminView;