// =================================================================
// FICHIER : src/pages/AboutUsPage.js
// Rôle : Page de présentation de la collaboration avec le design final.
// =================================================================
import React from 'react';
import vicLogo from '../assets/images/VIC_logo.png';
import allianceLogo from '../assets/images/alliance_logo.png';

const AboutUsPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-800 text-white p-10 flex items-center justify-center">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-5xl font-extrabold mb-12 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          Notre Collaboration
        </h1>
        
        <div className="bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 p-12 rounded-3xl shadow-2xl">
          {/* Logos des partenaires alignés */}
          <div className="flex justify-center items-center space-x-8 md:space-x-12">
            <img src={vicLogo} alt="VIC Tech Logo" className="h-16 md:h-20" />
            
            {/* Symbole d'union */}
            <svg className="w-12 h-12 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path>
            </svg>

            <img src={allianceLogo} alt="Alliance 3000 Logo" className="h-16 md:h-20" />
          </div>

          {/* Texte de présentation */}
          <div className="mt-10">
            <p className="text-2xl text-gray-300 leading-relaxed">
              Une alliance stratégique entre <span className="font-bold text-white">VIC Technologies</span> et <span className="font-bold text-white">Alliance 3000</span> pour réinventer la mobilité de demain.
            </p>
          </div>

          {/* Informations CEO */}
          <div className="mt-12 pt-8 border-t border-purple-500/20">
            <p className="text-lg text-gray-400">Dirigé par</p>
            <p className="text-3xl font-bold text-white mt-2">Mehdi</p>
            <p className="text-lg text-purple-400">PDG, VIC Technologies</p>
          </div>

          {/* Contact */}
          <div className="mt-12">
             <a 
                href="mailto:vic.sarlau@gmail.com" 
                className="inline-block bg-purple-600/80 hover:bg-purple-700 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105"
            >
                Contactez-nous : vic.sarlau@gmail.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUsPage;