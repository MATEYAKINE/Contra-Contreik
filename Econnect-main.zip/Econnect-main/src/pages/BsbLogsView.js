// =================================================================
// FICHIER : src/pages/BsbLogsView.js
// Rôle : Affiche les logs BSB (design adapté).
// =================================================================
import React, { useState, useEffect, useRef } from 'react';

const BsbLogsView = () => {
    const [logs, setLogs] = useState([]);
    const logContainerRef = useRef(null);

    useEffect(() => {
        const interval = setInterval(() => {
            const time = new Date().toLocaleTimeString('fr-FR');
            const types = ['INFO', 'WARN', 'DATA', 'ERROR'];
            const msgs = ['Engine temp: 55°C', 'Network stable', 'Passenger count: 12', 'Braking pressure OK', 'Vibration detected', 'GPS accuracy: HIGH'];
            const type = types[Math.floor(Math.random() * types.length)];
            const msg = msgs[Math.floor(Math.random() * msgs.length)];
            setLogs(prevLogs => [...prevLogs, { time, type, msg }]);
        }, 2500);
        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [logs]);

    const getLogColor = (type) => {
        switch(type) {
            case 'INFO': return 'text-blue-400';
            case 'WARN': return 'text-yellow-400';
            case 'ERROR': return 'text-red-400';
            case 'DATA': return 'text-green-400';
            default: return 'text-gray-400';
        }
    }

    return (
        <div className="bg-gray-900/60 backdrop-blur-xl border border-purple-500/20 rounded-2xl shadow-lg h-[75vh] flex flex-col">
            <div className="p-4 border-b border-gray-700/50">
                <h2 className="text-xl font-bold text-white">Terminal des Logs BSB</h2>
            </div>
            <div ref={logContainerRef} className="flex-grow overflow-y-auto p-4 font-mono text-sm space-y-1 custom-scrollbar">
                {logs.map((log, index) => (
                    <p key={index}>
                        <span className="text-gray-500">{log.time}</span>
                        <span className={`font-bold mx-2 ${getLogColor(log.type)}`}>[{log.type}]</span>
                        <span className="text-gray-300">{log.msg}</span>
                    </p>
                ))}
            </div>
        </div>
    );
};

export default BsbLogsView;
