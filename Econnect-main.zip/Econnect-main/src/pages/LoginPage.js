// =================================================================
// FICHIER : src/pages/LoginPage.js
// Rôle : Page de connexion avec champ conditionnel pour l'ID Chauffeur.
// =================================================================
import React, { useState, useEffect } from 'react';
import logo from '../assets/images/logo.png';

const LoginPage = ({ onLogin, onGoToWelcome, role }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const loadTimer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(loadTimer);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onLogin();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 text-white flex flex-col justify-center items-center p-4">
      <div className="max-w-md w-full mx-auto">
        <div className={`text-center mb-8 transform transition-all duration-800 ${isLoaded ? 'opacity-100' : 'opacity-0 -translate-y-5'}`}>
          <button onClick={onGoToWelcome} className="group relative inline-block">
            <img src={logo} alt="Connect Transit Logo" className="relative w-24 h-auto mx-auto transition-transform transform group-hover:scale-110" />
          </button>
        </div>

        <div className={`bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 p-8 rounded-2xl shadow-2xl transform transition-all duration-800 ${isLoaded ? 'opacity-100' : 'opacity-0 translate-y-5'}`} style={{ transitionDelay: '200ms' }}>
          <h2 className="text-2xl font-bold text-center text-white mb-6">
            {role === 'driver' ? 'Connexion Chauffeur' : 'Accédez à votre espace'}
          </h2>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              {/* Champ ID Chauffeur (conditionnel) */}
              {role === 'driver' && (
                <div>
                  <label htmlFor="driverId" className="block text-sm font-medium text-gray-300 mb-2">ID Chauffeur</label>
                  <input 
                    type="text" 
                    id="driverId" 
                    className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" 
                    placeholder="Entrez votre identifiant"
                  />
                </div>
              )}

              {/* Champ email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">Adresse e-mail</label>
                <input 
                  type="email" 
                  id="email" 
                  className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" 
                  placeholder="vous@exemple.com"
                />
              </div>

              {/* Champ mot de passe */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2">Mot de passe</label>
                <input 
                  type="password" 
                  id="password" 
                  className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" 
                  placeholder="********"
                />
              </div>

              {/* Bouton de connexion */}
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-4 rounded-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-50"
              >
                {isSubmitting ? 'Connexion...' : 'Se connecter'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
