// =================================================================
// FICHIER : src/pages/Placeholder.js
// Rôle : Affiche une page de remplacement avec le design moderne.
// =================================================================

import React from 'react';
import { icons } from '../api/mockData';
import Icon from '../components/Icon';

const Placeholder = ({ title }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center h-[70vh]">
      <div className="p-8 bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 rounded-2xl shadow-2xl">
        <div className="text-purple-400 mb-4">
            <Icon path={icons.maintenance} className="w-16 h-16 mx-auto" />
        </div>
        <h1 className="text-3xl font-bold text-white">
          {title}
        </h1>
        <p className="text-gray-400 mt-2">
          Cette section est en cours de développement.
        </p>
      </div>
    </div>
  );
};

export default Placeholder;
