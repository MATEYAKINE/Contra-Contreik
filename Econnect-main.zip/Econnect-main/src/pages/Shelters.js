// =================================================================
// FICHIER : src/pages/Shelters.js
// Rôle : Affiche la supervision des abribus avec le design moderne.
// =================================================================

import React from 'react';
import { mockData, icons } from '../api/mockData';
import Icon from '../components/Icon';

const Shelters = () => {
    const getStatusClass = (status) => {
        return status === 'Opérationnel' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300';
    };

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-white">Supervision des Abribus</h1>
            <p className="text-gray-400">Statut en temps réel des infrastructures d'abribus connectés.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockData.busShelters.map(shelter => (
                    <div key={shelter.id} className="bg-gray-900/40 backdrop-blur-xl border border-purple-500/20 rounded-2xl shadow-lg p-6 transform transition-all duration-300 hover:-translate-y-2">
                        <div className="flex justify-between items-start">
                            <div>
                                <h2 className="text-xl font-bold text-white">{shelter.id}</h2>
                                <p className="text-sm text-gray-400">{shelter.location}</p>
                            </div>
                            <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getStatusClass(shelter.status)}`}>
                                {shelter.status}
                            </span>
                        </div>
                        <div className="mt-6 space-y-4">
                            <div className="flex items-center text-gray-300">
                                <Icon path={icons.wifi} className="w-5 h-5 text-blue-400"/>
                                <span className="ml-3">Wi-Fi:</span>
                                <span className={`ml-auto font-semibold ${shelter.wifi === 'Actif' ? 'text-green-400' : 'text-red-400'}`}>{shelter.wifi}</span>
                            </div>
                            <div className="flex items-center text-gray-300">
                                <Icon path={icons.sun} className="w-5 h-5 text-yellow-400"/>
                                <span className="ml-3">Charge Solaire:</span>
                                <span className="ml-auto font-semibold">{shelter.solarPower}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Shelters;
