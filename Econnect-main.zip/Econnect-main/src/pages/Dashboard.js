// =================================================================
// FICHIER : src/pages/Dashboard.js
// Rôle : Affiche la page principale du tableau de bord avec la carte du réseau.
// =================================================================

import React, { useState, useEffect } from 'react';
import { mockData, icons } from '../api/mockData';
import Icon from '../components/Icon';
import mapImage from '../assets/images/maps.png'; // 1. Importer votre image

const Dashboard = () => {
    const ticketPrice = 5;
    const dailyPassengers = 7000;
    const dailyRevenue = (ticketPrice * dailyPassengers).toLocaleString('fr-FR');
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        const loadTimer = setTimeout(() => setIsLoaded(true), 100);
        return () => clearTimeout(loadTimer);
    }, []);

    const metrics = [
        { id: 'buses', title: 'Bus Actifs', value: '30', total: '50', icon: icons.fleet, color: 'blue' },
        { id: 'alerts', title: 'Alertes Actives', value: mockData.alerts.length, icon: icons.alerts, color: 'red' },
        { id: 'punctuality', title: 'Ponctualité', value: '96%', icon: 'clock', color: 'green' },
        { id: 'revenue', title: 'Revenu / jour', value: dailyRevenue, currency: 'MAD', icon: 'money', color: 'yellow' }
    ];

    const getIconElement = (iconType) => {
        switch (iconType) {
            case 'clock':
                return <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>;
            case 'money':
                return <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>;
            default:
                return <Icon path={iconType} className="w-7 h-7" />;
        }
    };
    
    const getColorClasses = (color) => {
        switch (color) {
            case 'blue': return 'bg-blue-500/20 text-blue-300';
            case 'red': return 'bg-red-500/20 text-red-300';
            case 'green': return 'bg-green-500/20 text-green-300';
            case 'yellow': return 'bg-yellow-500/20 text-yellow-300';
            default: return 'bg-gray-500/20 text-gray-300';
        }
    }

    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {metrics.map((metric, index) => (
                    <div
                        key={metric.id}
                        className={`bg-gray-900/40 backdrop-blur-xl border border-purple-500/20 p-6 rounded-2xl shadow-lg transform transition-all duration-500 hover:-translate-y-2 ${
                            isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                        }`}
                        style={{ transitionDelay: `${index * 100}ms` }}
                    >
                        <div className="flex items-center">
                            <div className={`p-3 rounded-xl ${getColorClasses(metric.color)}`}>
                                {getIconElement(metric.icon)}
                            </div>
                            <div className="ml-4">
                                <p className="text-gray-400 text-sm font-medium">{metric.title}</p>
                                <div className="flex items-baseline space-x-2">
                                    <p className="text-2xl font-bold text-white">{metric.value}</p>
                                    {metric.currency && <span className="text-sm font-medium text-gray-400">{metric.currency}</span>}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Carte du réseau (MISE À JOUR) */}
                    <div className={`lg:col-span-2 bg-gray-900/40 backdrop-blur-xl border border-purple-500/20 p-6 rounded-2xl shadow-lg transform transition-all duration-700 ${
                        isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                    }`} style={{ transitionDelay: '400ms' }}>
                        <h2 className="text-xl font-bold text-white mb-4">Carte du Réseau</h2>
                        <div className="relative bg-gray-800/50 rounded-xl overflow-hidden group">
                            {/* 2. Utiliser l'image importée */}
                            <img 
                                src={mapImage} 
                                alt="Carte du réseau de Casablanca" 
                                className="w-full h-96 object-cover"
                            />
                        </div>
                    </div>

                    {/* Flux d'alertes */}
                    <div className={`bg-gray-900/40 backdrop-blur-xl border border-purple-500/20 p-6 rounded-2xl shadow-lg transform transition-all duration-700 ${
                        isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                    }`} style={{ transitionDelay: '500ms' }}>
                        <h2 className="text-xl font-bold text-white mb-4">Flux d'Alertes</h2>
                        <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar pr-2">
                            {mockData.alerts.map((alert) => (
                                <div 
                                    key={alert.id} 
                                    className="flex items-start p-3 bg-gray-800/50 rounded-xl"
                                >
                                    <div className={`mt-1 p-2 rounded-full ${
                                        alert.priority === 'Haute' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                                    }`}>
                                        <Icon path={icons.alerts} className="w-4 h-4"/>
                                    </div>
                                    <div className="ml-3 flex-1">
                                        <p className="font-semibold text-white text-sm">{alert.type} - {alert.busId}</p>
                                        <p className="text-xs text-gray-400 mt-1">{alert.message}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
        </div>
    );
};

export default Dashboard;
