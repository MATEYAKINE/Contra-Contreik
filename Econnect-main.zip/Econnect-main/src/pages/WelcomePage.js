// =================================================================
// FICHIER : src/pages/WelcomePage.js
// Rôle : Page d'accueil présentant le projet avec un design moderne et dynamique.
// =================================================================

import React, { useState, useEffect } from 'react';
import vicLogo from '../assets/images/VIC_logo.png';
import allianceLogo from '../assets/images/alliance_logo.png';
import logo from '../assets/images/logo.png';

const WelcomePage = ({ onStart }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [particles, setParticles] = useState([]);

  // Animation d'apparition au chargement
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);

    // Génération de particules flottantes avec différentes couleurs
    const generateParticles = () => {
      const newParticles = [];
      const colors = ['bg-purple-400', 'bg-white', 'bg-violet-400', 'bg-fuchsia-400', 'bg-pink-400', 'bg-indigo-400'];
      
      for (let i = 0; i < 25; i++) {
        newParticles.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: Math.random() * 4 + 1,
          duration: Math.random() * 20 + 15,
          delay: Math.random() * 5,
          color: colors[Math.floor(Math.random() * colors.length)],
        });
      }
      setParticles(newParticles);
    };

    generateParticles();
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-800 to-indigo-900 text-white font-sans relative overflow-x-hidden">
      {/* Particules flottantes colorées */}
      <div className="absolute inset-0 pointer-events-none z-0">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className={`absolute ${particle.color} rounded-full opacity-30 blur-sm`}
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              animation: `float ${particle.duration}s ease-in-out infinite ${particle.delay}s`,
            }}
          />
        ))}
      </div>

      {/* Overlay coloré animé */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-white/5 to-violet-500/10 animate-pulse"></div>

      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center p-6 text-center relative z-10">
        <div className={`transform transition-all duration-1000 ${isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          {/* Logo principal simple et élégant */}
          <div className="mb-8 relative group">
            <img 
              src={logo} 
              alt="Connect Transit Logo" 
              className="h-16 w-auto md:h-20 md:w-auto object-contain filter drop-shadow-lg hover:drop-shadow-xl transition-all duration-300 transform hover:scale-105 mx-auto" 
            />
          </div>

          {/* Titre principal avec effet de gradient dynamique */}
          <h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-white via-purple-300 to-violet-400 bg-clip-text text-transparent drop-shadow-2xl">
            Connect Transit
          </h1>

          {/* Sous-titre avec couleurs vives */}
          <p className="text-xl md:text-2xl text-gray-200 mb-10 max-w-3xl leading-relaxed">
            Plateforme intelligente de supervision et communication <br />
            <span className="bg-gradient-to-r from-purple-400 to-white bg-clip-text text-transparent font-semibold text-2xl">
              pour les transports en temps réel
            </span>
          </p>

          {/* Bouton principal avec effet glassmorphism et couleurs vives */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 via-white to-violet-500 rounded-2xl blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse"></div>
            <button
              onClick={onStart}
              className="relative bg-white/10 backdrop-blur-xl border border-purple-400/50 p-8 rounded-2xl hover:bg-white/20 transition-all duration-300 cursor-pointer text-white transform hover:scale-105 active:scale-95 shadow-2xl hover:shadow-purple-500/30"
            >
              <div className="flex items-center justify-center space-x-3">
                <div className="w-3 h-3 bg-white rounded-full animate-pulse shadow-lg shadow-white/50"></div>
                <span className="text-2xl font-bold text-white drop-shadow-lg">
                  Commencer
                </span>
                <svg 
                  className="w-6 h-6 transform group-hover:translate-x-2 transition-transform duration-300 text-purple-300" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
              <p className="mt-3 text-sm text-purple-200 opacity-90">
                Supervision • Communication • Temps réel
              </p>
            </button>
          </div>

          {/* Scroll indicator */}
          <div className="mt-16 animate-bounce">
            <div className="flex flex-col items-center space-y-2">
              <span className="text-sm text-purple-300">Découvrez plus</span>
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-purple-400 bg-clip-text text-transparent">
              Fonctionnalités Principales
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Une solution complète pour la gestion intelligente de vos transports
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur-xl border border-purple-400/30 rounded-2xl p-8 transform hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl mb-6 flex items-center justify-center mx-auto shadow-lg shadow-purple-500/30">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 text-center">Supervision</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Surveillez tous vos véhicules en temps réel avec des tableaux de bord intuitifs et des alertes automatiques.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-xl border border-white/30 rounded-2xl p-8 transform hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-white/20">
              <div className="w-16 h-16 bg-gradient-to-br from-white to-gray-200 rounded-2xl mb-6 flex items-center justify-center mx-auto shadow-lg shadow-white/30">
                <svg className="w-8 h-8 text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 text-center">Communication</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Messagerie instantanée sécurisée entre conducteurs, dispatchers et équipes de maintenance.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-xl border border-violet-400/30 rounded-2xl p-8 transform hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-violet-500/20">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-400 to-violet-600 rounded-2xl mb-6 flex items-center justify-center mx-auto shadow-lg shadow-violet-500/30">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 text-center">Temps Réel</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Données GPS précises, statuts de véhicules et notifications instantanées pour une gestion optimale.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 px-6 bg-white/5 backdrop-blur-xl relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
              Performances & Fiabilité
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-black text-purple-400 mb-4">99.9%</div>
              <div className="text-white font-semibold mb-2">Uptime</div>
              <div className="text-gray-400 text-sm">Disponibilité garantie</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-black text-white mb-4">&lt;1s</div>
              <div className="text-white font-semibold mb-2">Latence</div>
              <div className="text-gray-400 text-sm">Temps de réponse</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-black text-violet-400 mb-4">24/7</div>
              <div className="text-white font-semibold mb-2">Support</div>
              <div className="text-gray-400 text-sm">Assistance continue</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-black text-purple-300 mb-4">100+</div>
              <div className="text-white font-semibold mb-2">Véhicules</div>
              <div className="text-gray-400 text-sm">Capacité système</div>
            </div>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-20 px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-white bg-clip-text text-transparent">
              Technologies Avancées
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Propulsé par les dernières innovations technologiques
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white/10 backdrop-blur-xl border border-purple-400/30 rounded-xl p-6 text-center hover:bg-white/20 transition-all duration-300">
              <div className="text-3xl mb-3">🚀</div>
              <div className="text-white font-semibold">WebSocket</div>
              <div className="text-gray-400 text-sm">Temps réel</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl border border-white/30 rounded-xl p-6 text-center hover:bg-white/20 transition-all duration-300">
              <div className="text-3xl mb-3">🌐</div>
              <div className="text-white font-semibold">GPS</div>
              <div className="text-gray-400 text-sm">Géolocalisation</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl border border-violet-400/30 rounded-xl p-6 text-center hover:bg-white/20 transition-all duration-300">
              <div className="text-3xl mb-3">🔒</div>
              <div className="text-white font-semibold">SSL/TLS</div>
              <div className="text-gray-400 text-sm">Sécurité</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl border border-purple-300/30 rounded-xl p-6 text-center hover:bg-white/20 transition-all duration-300">
              <div className="text-3xl mb-3">📊</div>
              <div className="text-white font-semibold">Analytics</div>
              <div className="text-gray-400 text-sm">Données</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900/90 backdrop-blur-xl border-t border-purple-500/30 p-6 w-full relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Section Partenaires */}
            <div className="flex items-center space-x-6">
              <span className="text-sm font-semibold text-gray-400 border-l-2 border-purple-500 pl-3">
                Nos Partenaires
              </span>
              <div className="flex items-center space-x-4">
                <img 
                  src={vicLogo} 
                  alt="VIC Tech Logo" 
                  className="h-10 filter grayscale hover:grayscale-0 transition-all duration-300 transform hover:scale-110 hover:drop-shadow-lg hover:drop-shadow-purple-500/50" 
                />
                <img 
                  src={allianceLogo} 
                  alt="Alliance 3000 Logo" 
                  className="h-12 filter grayscale hover:grayscale-0 transition-all duration-300 transform hover:scale-110 hover:drop-shadow-lg hover:drop-shadow-white/50" 
                />
              </div>
            </div>

            {/* Section Contact */}
            <div className="flex items-center space-x-4">
              <a 
                href="mailto:contact.alliance3000@gmail.com" 
                className="group flex items-center space-x-2 bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 rounded-lg px-4 py-2 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/25"
              >
                <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span className="text-sm font-semibold text-purple-300 group-hover:text-purple-200">
                  contact.alliance3000@gmail.com
                </span>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WelcomePage;