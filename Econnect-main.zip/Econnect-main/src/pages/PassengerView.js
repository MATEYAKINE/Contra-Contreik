// =================================================================
// FICHIER : src/pages/PassengerView.js
// Rôle : Interface pour le passager avec un flux de réservation complet.
// =================================================================
import React, { useState, useEffect } from 'react';

// --- Sous-composants pour chaque étape du flux de réservation ---

// Étape 1: Affichage des résultats de la recherche (MODIFIÉ)
const SearchResults = ({ results, onSelectRoute }) => (
  <div className="mt-8 space-y-4 animate-fade-in">
    <h3 className="text-xl font-bold text-white">Itinéraires disponibles</h3>
    {results.routes.map((route) => (
      <div key={route.id} className="bg-gray-900/50 border border-gray-700/50 p-4 rounded-xl hover:border-purple-500/30 transition-all">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-bold text-white">{route.name}</h4>
            <p className="text-sm text-gray-300">{route.stops} arrêts • {route.duration}</p>
            {/* Ajout de l'horaire et du prix */}
            <p className="text-sm text-purple-300 mt-1 font-semibold">Horaire: {route.schedule}</p>
            <p className="text-sm text-yellow-400 mt-1 font-semibold">Prix: {route.price} MAD</p>
          </div>
          <div className="text-right">
            <p className="text-green-400 font-bold">Prochain bus</p>
            <p className="text-sm text-gray-300">{route.next}</p>
          </div>
          <button onClick={() => onSelectRoute(route)} className="bg-purple-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            Sélectionner
          </button>
        </div>
      </div>
    ))}
  </div>
);

// Étape 2: Sélection du nombre de tickets
const TicketSelection = ({ route, onConfirm }) => {
  const [count, setCount] = useState(1);
  const ticketPrice = 5; // Prix fixe par ticket

  return (
    <div className="mt-8 animate-fade-in">
      <h3 className="text-xl font-bold text-white">Réservation pour: {route.name}</h3>
      <div className="mt-4 bg-gray-900/50 p-6 rounded-xl">
        <div className="flex justify-between items-center">
          <label className="font-semibold text-gray-300">Nombre de passagers :</label>
          <div className="flex items-center space-x-4">
            <button onClick={() => setCount(c => Math.max(1, c - 1))} className="w-10 h-10 bg-gray-700 rounded-full font-bold text-lg">-</button>
            <span className="text-2xl font-bold w-12 text-center">{count}</span>
            <button onClick={() => setCount(c => c + 1)} className="w-10 h-10 bg-gray-700 rounded-full font-bold text-lg">+</button>
          </div>
        </div>
        <div className="mt-6 pt-4 border-t border-gray-700 flex justify-between items-center">
          <span className="text-lg font-bold text-white">Total à payer :</span>
          <span className="text-2xl font-bold text-purple-400">{count * ticketPrice} MAD</span>
        </div>
      </div>
      <button onClick={() => onConfirm(count)} className="mt-6 w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105">
        Procéder au paiement
      </button>
    </div>
  );
};

// Étape 3: Saisie des informations personnelles
const PassengerInfo = ({ onConfirm }) => {
    return (
        <div className="mt-8 animate-fade-in">
            <h3 className="text-xl font-bold text-white mb-4">Informations du Passager Principal</h3>
            <div className="space-y-4">
                <input className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Nom complet" />
                <input type="email" className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Adresse e-mail" />
                <input type="tel" className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Numéro de téléphone" />
            </div>
            <button onClick={onConfirm} className="mt-6 w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-6 rounded-xl transition-all hover:scale-105">
                Continuer vers le paiement
            </button>
        </div>
    );
};

// Étape 4: Saisie des informations de paiement
const PaymentForm = ({ onConfirm }) => {
    return (
        <div className="mt-8 animate-fade-in">
            <h3 className="text-xl font-bold text-white mb-4">Informations de Paiement</h3>
            <div className="space-y-4">
                <input className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Numéro de carte" />
                <div className="grid grid-cols-2 gap-4">
                    <input className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="MM/AA" />
                    <input className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="CVC" />
                </div>
            </div>
            <button onClick={onConfirm} className="mt-6 w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold py-3 px-6 rounded-xl transition-all hover:scale-105">
                Payer
            </button>
        </div>
    );
};


// Étape 5: Message de succès et pop-up de notation
const SuccessMessage = ({ onRate }) => (
  <div className="mt-8 text-center animate-fade-in">
    <svg className="w-24 h-24 text-green-400 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    <h3 className="text-2xl font-bold text-white mt-4">Paiement Réussi !</h3>
    <p className="text-gray-300 mt-2">Votre ticket a été envoyé à votre adresse e-mail.</p>
    <button onClick={onRate} className="mt-6 text-purple-400 font-semibold hover:underline">
      Évaluer votre expérience
    </button>
  </div>
);

const RatingModal = ({ isOpen, onClose }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50">
            <div className="bg-gray-800 p-8 rounded-2xl shadow-2xl text-center w-full max-w-sm">
                <h3 className="text-2xl font-bold text-white">Votre avis nous intéresse</h3>
                <p className="text-gray-400 mt-2 mb-6">Comment évalueriez-vous votre expérience ?</p>
                <div className="flex justify-center space-x-4 text-4xl">
                    <button className="transform hover:scale-125 transition">😞</button>
                    <button className="transform hover:scale-125 transition">😐</button>
                    <button className="transform hover:scale-125 transition">😊</button>
                    <button className="transform hover:scale-125 transition">😁</button>
                    <button className="transform hover:scale-125 transition">🤩</button>
                </div>
                <button onClick={onClose} className="mt-8 w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-lg">
                    Envoyer
                </button>
            </div>
        </div>
    );
};


// --- Composant Principal de la Vue Passager ---

const PassengerView = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState(null);
  const [bookingStep, setBookingStep] = useState('search'); // 'search', 'selection', 'info', 'payment', 'success'
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);

  useEffect(() => {
    const loadTimer = setTimeout(() => setIsLoaded(true), 300);
    return () => clearTimeout(loadTimer);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    setIsSearching(true);
    setSearchResults(null);
    setBookingStep('search');
    setTimeout(() => {
      setIsSearching(false);
      setSearchResults({
        routes: [
          // Ajout des horaires et prix
          { id: 1, name: 'Ligne 12', duration: '25 min', stops: 8, next: '3 min', schedule: '08H45 - 09H10', price: 5 },
          { id: 2, name: 'Ligne 8', duration: '32 min', stops: 12, next: '7 min', schedule: '09H00 - 09H32', price: 5 },
        ]
      });
    }, 1500);
  };

  const handleSelectRoute = (route) => {
    setSelectedRoute(route);
    setBookingStep('selection');
  };
  
  const resetFlow = () => {
      setSearchResults(null);
      setBookingStep('search');
      setSelectedRoute(null);
  }

  const renderBookingStep = () => {
    switch (bookingStep) {
        case 'selection':
            return <TicketSelection route={selectedRoute} onConfirm={() => setBookingStep('info')} />;
        case 'info':
            return <PassengerInfo onConfirm={() => setBookingStep('payment')} />;
        case 'payment':
            return <PaymentForm onConfirm={() => setBookingStep('success')} />;
        case 'success':
            return <SuccessMessage onRate={() => setIsRatingModalOpen(true)} />;
        default:
            return searchResults && <SearchResults results={searchResults} onSelectRoute={handleSelectRoute} />;
    }
  }

  return (
    <>
      <div className="relative min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 text-white p-4 md:p-10">
        <div className="relative z-10">
          <div className={`text-center transform transition-all duration-800 ${isLoaded ? 'opacity-100' : 'opacity-0 -translate-y-5'}`}>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {bookingStep === 'search' ? "Bienvenue sur Connect Transit" : "Finalisez votre réservation"}
            </h1>
          </div>
          <div className="mt-8 max-w-4xl mx-auto">
            <div className={`bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 p-6 md:p-8 rounded-2xl shadow-2xl transition-all duration-800 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
              
              {bookingStep === 'search' && (
                <>
                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 text-center">Planifiez votre trajet</h2>
                  <form onSubmit={handleSearch}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <input type="text" className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Point de départ" />
                      <input type="text" className="w-full px-4 py-3 bg-gray-900/50 border-2 border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500" placeholder="Destination" />
                    </div>
                    <button type="submit" disabled={isSearching} className="group w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-50">
                      <span className="relative flex items-center justify-center">
                        {isSearching ? <><svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Recherche...</> : 'Rechercher un itinéraire'}
                      </span>
                    </button>
                  </form>
                </>
              )}
              
              {renderBookingStep()}

              {bookingStep !== 'search' && (
                <button onClick={resetFlow} className="text-gray-400 text-sm mt-6 hover:text-white w-full">Retour à la recherche</button>
              )}

            </div>
          </div>
        </div>
      </div>
      <RatingModal isOpen={isRatingModalOpen} onClose={() => setIsRatingModalOpen(false)} />
    </>
  );
};

export default PassengerView;
