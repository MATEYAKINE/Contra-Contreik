// =================================================================
// FICHIER : src/pages/DriverView.js
// Rôle : Affiche l'interface pour le chauffeur avec son planning.
// =================================================================

import React from 'react';

// Données de simulation pour le planning du chauffeur
const driverSchedule = [
  { time: '08:00', location: 'Départ Dépôt', status: 'Fait' },
  { time: '08:15', location: 'Place des Nations Unies', status: 'Fait' },
  { time: '08:30', location: 'Boulevard d\'Anfa', status: 'En cours' },
  { time: '08:45', location: 'Twin Center', status: 'À venir' },
  { time: '09:00', location: 'Parc de la Ligue Arabe', status: 'À venir' },
  { time: '09:15', location: 'Gare de Casa-Port', status: 'À venir' },
];

const DriverView = () => {

  const getStatusIndicator = (status) => {
    switch (status) {
      case 'Fait':
        return <div className="w-5 h-5 bg-green-500/30 rounded-full flex items-center justify-center"><svg className="w-3 h-3 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg></div>;
      case 'En cours':
        return <div className="w-5 h-5 bg-purple-500/30 rounded-full flex items-center justify-center"><div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div></div>;
      case 'À venir':
        return <div className="w-5 h-5 bg-gray-700 border-2 border-gray-600 rounded-full"></div>;
      default:
        return null;
    }
  };

  const currentStop = driverSchedule.find(stop => stop.status === 'En cours');

  return (
    <div className="p-6 md:p-10 bg-gray-900 text-white min-h-screen font-sans">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Section de gauche : Planning de la journée */}
        <div className="lg:col-span-2 bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 p-8 rounded-2xl shadow-2xl">
          <h2 className="text-3xl font-bold text-white mb-6">Feuille de Route</h2>
          <div className="relative pl-5">
            {/* Ligne verticale de la timeline */}
            <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-gray-700"></div>

            {driverSchedule.map((stop, index) => (
              <div key={index} className="relative flex items-start mb-8">
                <div className="z-10 absolute left-0 top-1">
                  {getStatusIndicator(stop.status)}
                </div>
                <div className="pl-10">
                  <p className={`font-bold text-lg ${stop.status === 'En cours' ? 'text-purple-400' : 'text-white'}`}>{stop.location}</p>
                  <p className="text-sm text-gray-400">{stop.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section de droite : Informations et actions */}
        <div className="space-y-8">
          {/* Prochain arrêt */}
          <div className="bg-gray-800/40 backdrop-blur-xl border border-purple-500/20 p-6 rounded-2xl shadow-lg text-center">
            <p className="text-lg text-gray-400 uppercase tracking-widest">Prochain Arrêt</p>
            <h3 className="text-4xl font-bold text-purple-400 mt-2">
              {currentStop ? currentStop.location : 'Terminus'}
            </h3>
            <div className="mt-4 inline-flex items-center space-x-2 bg-green-500/20 text-green-300 px-4 py-2 rounded-full">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <span>À l'heure</span>
            </div>
          </div>

          {/* Actions rapides */}
          <div className="grid grid-cols-1 gap-4">
            <button className="w-full bg-blue-600/80 hover:bg-blue-600 text-white font-bold py-5 rounded-xl text-lg transition duration-300 transform hover:scale-105">
              Message Central
            </button>
            <button className="w-full bg-red-600/80 hover:bg-red-600 text-white font-bold py-5 rounded-xl text-lg transition duration-300 transform hover:scale-105 animate-pulse">
              Alerte Urgence
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DriverView;
