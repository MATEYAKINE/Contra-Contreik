// =================================================================
// FICHIER : src/App.js
// Rôle : Gère le flux principal de l'application.
// =================================================================

import React, { useState } from 'react';
import WelcomePage from './pages/WelcomePage';
import LoginPage from './pages/LoginPage';
import RoleSelectionModal from './components/RoleSelectionModal';
import PassengerView from './pages/PassengerView';
import DriverView from './pages/DriverView';
import AdminView from './pages/AdminView';
import AboutUsPage from './pages/AboutUsPage';
import MainNavbar from './components/MainNavbar'; 

export default function App() {
  const [appState, setAppState] = useState('welcome');
  const [userRole, setUserRole] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [roleToLogin, setRoleToLogin] = useState(null);

  const handleStart = () => {
    setIsModalOpen(true);
  };

  const handleRoleSelectForLogin = (role) => {
    setRoleToLogin(role);
    setAppState('login');
    setIsModalOpen(false);
  };

  const handleLogin = () => {
    if (roleToLogin) {
      setAppState(roleToLogin);
      setUserRole(roleToLogin);
    }
  };
  
  const handleLogout = () => {
    setAppState('welcome');
    setUserRole(null);
    setRoleToLogin(null);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleNavigate = (view) => {
    setAppState(view);
  };
  
  const handleGoToWelcome = () => {
    setAppState('welcome');
  };

  const renderMainView = () => {
    switch (appState) {
      case 'passenger':
        return <PassengerView />;
      case 'driver':
        return <DriverView />;
      case 'admin':
        return <AdminView />;
      case 'about':
        return <AboutUsPage />;
      default:
        return <WelcomePage onStart={handleStart} />;
    }
  };

  if (appState === 'welcome') {
    return (
      <>
        <WelcomePage onStart={handleStart} />
        <RoleSelectionModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          onSelectRole={handleRoleSelectForLogin}
        />
      </>
    );
  }

  if (appState === 'login') {
    return <LoginPage onLogin={handleLogin} onGoToWelcome={handleGoToWelcome} role={roleToLogin} />;
  }

  return (
    <div>
      <MainNavbar 
        onLogout={handleLogout} 
        onNavigate={handleNavigate}
        userRole={userRole}
      />
      <main>
        {renderMainView()}
      </main>
    </div>
  );
}
